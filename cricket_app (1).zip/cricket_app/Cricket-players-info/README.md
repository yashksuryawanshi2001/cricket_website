# Cricket-players-info

open login page (cricket.html)
give username and password(un:nanda,pw:nanda) 
click on player name to know about him.
